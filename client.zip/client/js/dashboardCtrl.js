app.controller('dashboardCtrl', function ($scope, dashboardService) {
    
});